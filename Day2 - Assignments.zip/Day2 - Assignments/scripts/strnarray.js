let name = "Deepak";
    let skill = "Coding";
    let weakness = "Shyness";
    
    console.log("The name is " + name + ", his skill is " + skill + " and his weakness is " + weakness);
    
    console.log(`The name is ${name}, his skill is ${skill} and his weakness is ${weakness}.`);



let arr = ['delhi', 'mumbai', 'kolkata'];
console.log(arr);


console.log(Array.isArray('text')); // text is string so its false
console.log(Array.isArray('arr'));   // indexOf('value')

console.log(arr.reverse());
console.log(arr[3]);
console.log(arr.concat(arr));

//appending an element from the start
arr.unshift('delhi');
console.log(arr2);

//appending an element from the end
arr.push('japan');
console.log(arr);


//removing an element from the start
arr.shift('tokyo');
console.log(arr);

//removing an element from the end
console.log(arr.pop())

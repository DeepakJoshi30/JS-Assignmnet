let name = prompt("Enter your name");
console.log(name);
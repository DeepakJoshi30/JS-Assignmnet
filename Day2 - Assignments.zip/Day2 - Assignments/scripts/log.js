console.log("Ask the user if he is 21+ and log the value can Drink, can not drink");

let age = +prompt("Enter your age", 0);

console.log(age, typeof age);

if (age >= 21){
console.log('You Can Drink');
}
else{
console.log('You Can Not Drink');
}
console.log("Even or Odd");

//Even and Odd

num = +prompt("enter a number",0)
    if(num%2==0){
        console.log("The number entered is " + num, "and Number is even");
    }
    else{
        console.log("The number entered is " + num, "and Number is Odd");
    }


//OS name and its version

    android = prompt("Write Your Operating System Name");
    version = prompt("write your Android Verion Name");
    
    console.log("Your Operating System Name is " + android + " And its Version is " + version);


// Marks and its Grade

marks = +prompt("Enter the Marks")
if (marks >= 90) {
  console.log(" Marks are " + marks + " and grade is A");
} else if (marks >= 80) {
    console.log(" Marks are " + marks + " and grade is B");
} else if (marks >= 70) {
    console.log(" Marks are " + marks + " and grade is C");
} else if (marks >= 60) {
    console.log(" Marks are " + marks + " and grade is D");
} else {
    console.log(" Marks are " + marks + " and grade is F");
}
